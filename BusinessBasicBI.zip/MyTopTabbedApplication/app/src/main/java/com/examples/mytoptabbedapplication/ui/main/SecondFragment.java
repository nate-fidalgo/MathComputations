package com.examples.mytoptabbedapplication.ui.main;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.examples.mytoptabbedapplication.R;

public class SecondFragment extends Fragment implements View.OnClickListener {

    TextView btv ;  //holds the Borrowed amount textarea
    TextView itv ;  //holds the annual interest rate textarea
    TextView ntv ;  //holds the payback time textarea
    TextView mtv ;  //holds the resulting mortgage calculation textarea


    public SecondFragment() {
// Required empty public constructor
        TextView btv ;  //holds the Borrowed amount textarea
        TextView itv ;  //holds the annual interest rate textarea
        TextView ntv ;  //holds the payback time textarea
        TextView rtv ;  //holds the resulting mortgage calculation textarea


    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    public void onClick(View view)
    {
        // switch (view.getId()) {
        //  case R.id.button2:
        // Do something
        //   }

        CharSequence B =  btv.getText() ;
        CharSequence I = itv.getText();
        CharSequence N =  ntv.getText();
        CharSequence M =  mtv.getText();
        double b = Double.parseDouble(B.toString()) ;
        double i = Double.parseDouble(I.toString()) / 12 ;  // annual interest rate divide my 12 for the monthly interest rate!!!
        double n = Integer.parseInt(N.toString()) ;
        //Bxix(1+i)^n/[(1+i)^n - 1]
        double m = b*i*Math.pow( (1+i) , n ) / (Math.pow( (1+i) , n ) - 1 ) ; //Double.parseDouble(M.toString()) ;

        mtv.setText( "   Monthly Payment $" + m );

        Log.i("INFOFRAMES" ,  "Button was pressed mortgage calc!!!") ;

        // Toast.makeText( getActivity().getApplicationContext() , "I got clicked " , Toast.LENGTH_LONG) ;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
// Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_second, container, false);
        View vw = inflater.inflate(R.layout.fragment_second, container, false);
        Button btn = vw.findViewById(R.id.mortgagebtn) ;
        btn.setOnClickListener(this);

        btv = vw.findViewById(R.id.borrow_result) ;
        itv = vw.findViewById(R.id.anninterest_result) ;
        ntv = vw.findViewById(R.id.payback_result) ;
        mtv = vw.findViewById(R.id.mortgage_result) ;


        return vw ;

    }

}
