package com.examples.mytoptabbedapplication.ui.main;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.examples.mytoptabbedapplication.R;

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class SectionsPagerAdapter extends FragmentPagerAdapter {

    @StringRes
    private static final int[] TAB_TITLES = new int[]{R.string.tab_text_1, R.string.tab_text_2 , R.string.tab_text_3 ,R.string.tab_text_4 };
    private final Context mContext;

    public SectionsPagerAdapter(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @Override
    public Fragment getItem(int position) {
        // getItem is called to instantiate the fragment for the given page.

        switch (position) {
            case 0:
                Log.i("INFOFRAMES" ,  "accounting from case 0") ;
                FirstFragment accounting = new FirstFragment();
                return accounting;
            case 1:
                Log.i("INFOFRAMES" ,  "finance from case 1") ;
                SecondFragment finance = new SecondFragment();
                return finance;
            case 2:
                Log.i("INFOFRAMES" ,  "actuarial from case 2") ;
                ThirdFragment actuarial = new ThirdFragment();
                return actuarial;
            case 3:
                Log.i("INFOFRAMES" ,  "economics from case 3") ;
                FourFragment economics = new FourFragment();
                return economics;

             default:
                return null;
        }

    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mContext.getResources().getString(TAB_TITLES[position]);
    }

    @Override
    public int getCount() {
        // Show 4 total tabs.
        return 4;
    }
}