package com.examples.mytoptabbedapplication.ui.main;

import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

public class PageViewModel extends ViewModel {

    private MutableLiveData<Integer> mIndex = new MutableLiveData<>();
    private LiveData<String> mText = Transformations.map(mIndex, new Function<Integer, String>() {
        @Override
        public String apply(Integer input) {
            //return "Hello world from section: " + input;
            if( input.intValue() == 1)
            {
                return "Hello world from section: 1" ;
            }

            if( input.intValue() == 2)
            {
                return "Financing ... " ;
            }

            if( input.intValue() == 3)
            {
                return "Economics  ... " ;
            }

            if( input.intValue() == 4)
            {
                return "Ec436363ics  ... " ;
            }

            return "9523525" ;
        }
    });

    public void setIndex(int index) {
        mIndex.setValue(index);
    }

    public LiveData<String> getText() {
        return mText;
    }
}