package com.examples.mytoptabbedapplication.ui.main;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.examples.mytoptabbedapplication.R;

public class FirstFragment extends Fragment implements View.OnClickListener {

    TextView ptv ;  //holds the principal textarea
    TextView rtv ;  //holds the compound interest rate textarea
    TextView ntv ;  //holds the conversion period textarea
    TextView ttv ;  //holds the time textarea
    TextView atv ;  //holds the answer textarea



    public FirstFragment() {
// Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }


    public void onClick(View view)
    {
       // switch (view.getId()) {
      //  case R.id.button2:
        // Do something
     //   }

/*        TextView ptv ;  //holds the principal textarea
        TextView rtv ;  //holds the compound interest rate textarea
        TextView ntv ;  //holds the conversion period textarea
        TextView ttv ;  //holds the time textarea
        TextView atv ;  //holds the answer textarea

        ptv = view.findViewById(R.id.prin_result) ;
        rtv = view.findViewById(R.id.com_result) ;
        ntv = view.findViewById(R.id.con_result) ;
        ttv = view.findViewById(R.id.time_result) ;
        atv = view.findViewById(R.id.compoundint_result) ;


 */

        CharSequence P =  ptv.getText() ;
        CharSequence RR = rtv.getText();
        CharSequence N =  ntv.getText();
        CharSequence T =  ttv.getText();
        CharSequence A =  atv.getText();
        double p = Double.parseDouble(P.toString()) ;
        double r = Double.parseDouble(RR.toString()) ;
        double n = Integer.parseInt(N.toString()) ;
        r = r/n ; // nominal rate / conversion period  = the compound rate !!!
        double t = Double.parseDouble(T.toString()) ;

        double a = ( p * Math.pow( (1+r) , n*t ) ) ;
        atv.setText("    Your With Holdings is $" +a) ;
        //atv.setText(A);
        //  compoundint_result
     //   P(1+r)^nt


        Log.i("INFOFRAMES" ,  "Button was pressed compound interest !!!") ;
       // Toast.makeText( getActivity().getApplicationContext() , "I got clicked " , Toast.LENGTH_LONG) ;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
// Inflate the layout for this fragment
       // Button btn =  findViewById( R.id.button2 ) ;
       // mButton = findViewById(R.id.button_send);
       // mButton.setOnClickListener(this);
        View vw = inflater.inflate(R.layout.fragment_first, container, false);
        Button btn = vw.findViewById(R.id.cinterestbtn) ;
        btn.setOnClickListener(this);


        ptv = vw.findViewById(R.id.prin_result) ;
        rtv = vw.findViewById(R.id.com_result) ;
        ntv = vw.findViewById(R.id.con_result) ;
        ttv = vw.findViewById(R.id.time_result) ;
        atv = vw.findViewById(R.id.compoundint_result) ;


        return vw ; //inflater.inflate(R.layout.fragment_first, container, false);
    }

}