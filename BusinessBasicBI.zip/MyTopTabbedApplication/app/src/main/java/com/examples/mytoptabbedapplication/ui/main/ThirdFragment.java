package com.examples.mytoptabbedapplication.ui.main;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.examples.mytoptabbedapplication.R;

public class ThirdFragment extends Fragment {


    public ThirdFragment() {
// Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
// Inflate the layout for this fragment
       //###################ADD YOUR CODE FOR THIS FRAGMENT HERE

        return inflater.inflate(R.layout.fragment_third, container, false);
    }

}